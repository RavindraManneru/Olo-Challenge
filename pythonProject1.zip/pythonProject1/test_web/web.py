import requests
'''
reusable methods to take url info and payload information and return information
Exceptions are propagated.  
'''


def get_request(url, payload=None):
    """
    The get, post and put methods in this module have the same
    :param url: address of site being
    :param payload: optional parameters for url
    :return: unpacked json
    """
    resp = requests.get(url, params=payload)
    return resp.json()


def post_request(url, payload=None):
    """
    will perform post requests.
    :param url:
    :param payload: optional data for request
    :return:unpacked json
    """
    resp = requests.post(url, data=payload)
    return resp.json()


def put_request(url, payload):
    """
    performs a put request.
    :param url: url of request
    :param payload: required information to be sent
    :return: unpacked json response
    """
    resp = requests.put(url, data=payload)
    return resp.json()


def delete_request(url):
    """

    :param url: url of request
    :return: unpacked json (will be an empty dict)
    """
    resp = requests.put(url)
    return resp.text
