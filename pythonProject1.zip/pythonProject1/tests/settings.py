"""
Will store some information needed to run tests.
"""

POSTS_URL = 'https://jsonplaceholder.typicode.com/posts'
COMMENTS_URL = 'https://jsonplaceholder.typicode.com/comments'
DELETE_URL = 'https://jsonplaceholder.typicode.com/posts/{0}'
