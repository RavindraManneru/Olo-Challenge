import unittest
import logging
import settings
from test_web import web
logging.basicConfig(level=logging.INFO)

"look at this for info Ravi https://docs.python.org/3/library/unittest.html/"
class TestJsonPlaceHolder(unittest.TestCase):

    def test_put(self):

        payload = {'id': 1, 'some other things': 'I like soccer'}
        response = web.post_request(settings.POSTS_URL, payload)
        self.assertIsNotNone(response)

    def test_del(self):
        item = '42342342342'
        self.assertIsNotNone(web.delete_request(settings.DELETE_URL.format(item)))

    def test_get(self):
        payload = {'postId': 1}
        resp1 = web.get_request(settings.COMMENTS_URL, payload)
        resp2 = web.get_request(settings.POSTS_URL)
        self.assertNotEqual(resp1, resp2)

    def test_post(self):
        new_post = {"newPost": "stuff", "soccer": "lvp"}
        response = web.post_request(settings.POSTS_URL, new_post)
        self.assertTrue("soccer" in response)

if __name__ == '__main__':
    unittest.main()
